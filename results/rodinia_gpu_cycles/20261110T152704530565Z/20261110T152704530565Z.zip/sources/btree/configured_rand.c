/* Matches the documented random_values=[0] scenario. */
int rand(void) { return 0; }
