#ifdef __cplusplus
#include <cuda_runtime.h>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <ctime>
#else
#include <string.h>
#include <time.h>
int cudaSetDevice(int);
#endif
